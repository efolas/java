/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dosya;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.accessibility.AccessibleContext;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextField;

/**
 *
 * @author zafer
 */
public class GUI extends JFrame implements ActionListener{
    JFrame jframe;
    JPanel jpanel;
    JButton bLogin,bList;
    JLabel user,userPassword;
    final JTextField userName,password;
    
    
    public GUI() {
       
        bList=new JButton("Listele");
        bList.setBounds(275, 220, 100, 30);
        bLogin=new JButton("Login");
        bLogin.setBounds(125,220,100,30);
        userName=new JTextField();
        userName.setBounds(275, 100, 100, 25);
        password=new JTextField();
        password.setBounds(275, 150, 100, 25);
        user=new JLabel("Kullanıcı Adı :");
        user.setBounds(125,100,100,25);
        userPassword=new JLabel("Sifre :");
        userPassword.setBounds(125,150,100,25);
        
        jpanel=new JPanel();
        jpanel.setLayout(null);
        jpanel.add(user);
        jpanel.add(userPassword);
        jpanel.add(password);
        jpanel.add(userName);
        jpanel.add(bList);
        jpanel.add(bLogin);
        add(jpanel);
        
        bLogin.addActionListener(this);
        bList.addActionListener(this);
    }
 
   
    @Override
    public void actionPerformed(ActionEvent GUI) {
        ControlPanel c=new ControlPanel();
        
        String userNameVal=userName.getText();
        String passwordVal=password.getText();
        
        if(GUI.getSource()==bLogin){
            try {
                c.Yazma(userNameVal,passwordVal);
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else if(GUI.getSource()==bList){
            try {
                c.Okuma();
            } catch (IOException ex) {
                Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }    
}
