/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package binaryTree;

import java.util.Scanner;

/**
 *
 * @author zafer
 */
public class tree {

    Node kok = new Node();
    Scanner scan = new Scanner(System.in);

    public void Ekle(int deger, Node gecici) {
        if (gecici.deger <= deger) {
            if (gecici.sag == null) {
                Node yeniDugum = new Node(deger);
                gecici.sag = yeniDugum;
            } else {
                Ekle(deger, gecici.sag);
            }
        } else if (gecici.deger > deger) {
            if (gecici.sol == null) {
                Node yeniDugum = new Node(deger);
                gecici.sol = yeniDugum;
            } else {
                Ekle(deger, gecici.sol);
            }
        }
    }

    public Node Sil2(Node kok,int deger) {
        if (kok.deger== deger) { 
                if (kok.sol == null && kok.sag == null)
                {
                    return null;
                }
                if (kok.sag != null) { 
                    kok.deger = min(kok.sag); 
                    kok.sag = Sil2(kok.sag, min(kok.sag));
                    return kok;
                }
                kok.deger = max(kok.sol); 
                kok.sol = Sil2(kok.sol, max(kok.sol)); 
                return kok;
            }
            if (kok.deger< deger) 
            {
                kok.sag = Sil2(kok.sag, deger);
                return kok;
            }
            kok.sol= Sil2(kok.sol, deger); 
            return kok;

    }
    
    public void inorder(Node kok){
        if (kok == null)
            return;
 
        inorder(kok.sol);
        System.out.print(kok.deger + " ");
        inorder(kok.sag);
    }

    public void Arama(int deger, Node kok) {
        if (kok == null) {
            System.out.println(deger + " Sayisi Bulunamamistir");
            return;
        }
        if (kok.deger == deger) {
            System.out.println(deger + " Sayisi bulunmustur");
        } else if (kok.deger > deger) {
            Arama(deger, kok.sol);
        } else if (kok.deger < deger) {
            Arama(deger, kok.sag);
        }

    }

    private int min(Node kok) {
        while(kok.sag!=null){
            kok=kok.sag;
        }
        return kok.deger;
    }

    private int max(Node kok) {
        while(kok.sol!=null){
            kok=kok.sol;
        }
        return kok.deger;      
    }

}
