package binaryTree;

import java.util.Scanner;

/**
 *
 * @author zafer
 */
public class BinaryTree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int secim;
        int deger;
        tree t = new tree();

        do {
            System.out.println("");
            System.out.println("Lutfen yapmak istediginiz islemi giriniz: ");
            System.out.println("1-) Ekleme islemi.");
            System.out.println("2-) Arama islemi.");
            System.out.println("3-) Yazdirma islemi.");
            System.out.println("4-) Silme islemi.");
            System.out.println("0-) Cikis..");
            System.out.print("Seciminiz nedir: ");
            secim = scan.nextInt();
            switch (secim) {
                case 1:
                    System.out.print("Agaca eklemek istediginiz veriyi giriniz: ");
                    deger = scan.nextInt();
                    if (t.kok == null) {
                        t.kok = new Node(deger);
                        break;
                    }
                    t.Ekle(deger, t.kok);
                    break;
                case 2:

                    System.out.print("Agaca eklemek istediginiz veriyi giriniz: ");
                    deger = scan.nextInt();
                    if (t.kok == null) {
                        System.out.println("Agac Bos!!");
                        break;
                    }
                    t.Arama(deger, t.kok);
                    break;
                case 3:
                    t.inorder(t.kok);
                    break;
                case 4:
                    System.out.print("Agaca eklemek istediginiz veriyi giriniz: ");
                    deger = scan.nextInt();
                    if (t.kok == null) {
                        System.out.println("Agac Bos!!");
                        break;
                    }
                    t.Sil2(t.kok, deger);
                    break;
            }
        } while (secim != 0);

    }

}
