/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package binaryTree;

/**
 *
 * @author zafer
 */
public class Node {
    int deger;
    Node sol;
    Node sag;

    public Node() {
        
    }

    public Node(int deger) {
        this.deger = deger;
        this.sag=null;
        this.sol=null;
    }
    
    
}
